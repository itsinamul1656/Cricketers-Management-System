# Cricketers Management System

run server: 

    npm install
    npm start


1. Create a admin login page
    Should be able to enter username / password

    Once login is clicked, it should check the validity of the admin and login


2. add cricketer up page
    Option to register as new user

    Fields needed for signup

    first name
    last name
    jersey number
    total matches
    over all scores
    category
    representing country


3. After successful login the admin should land up in the home page.
    
    Links in the home page
    
    Cricketers Profile
    
    Messages
    
    Logout


4. Profile page
    
    Option for updating the user basic information
    
    Username
    
    Password
    
    Firstname
    
    Lastname
    
    Email
    
    Phone
    
    Location


5. Messages page
    
    List all the messages available for the user
    
    Once the user clicks on a message show the entire message in a different page with an options to 
    
    Reply : once a reply is received it should show below the original message.
    
    Delete : once deleted need to redirect the user to messages listing page
    
    Mark as important
    
    Back to messages


6. Logout
    
    Once clicked on logout, redirect the user back to login page.


7. MongoDB
    
    All the data in the system is stored in MongoDB.

