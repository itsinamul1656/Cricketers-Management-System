module.exports = {
     // Development configuration options
};
