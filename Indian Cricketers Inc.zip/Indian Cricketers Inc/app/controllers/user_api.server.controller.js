var Cricketer = require('../models/user');  //user model in user collection of cricketer database
var Admin = require('../models/admin');  //admin model in user collection of admin database

exports.create = function(req, res) {
  console.log('new user data');
  console.log(req.body);
  var newCricketer = new Cricketer(req.body);
  newCricketer.save(function(err, result){
    if (err){
      console.log('save new user error at user_api.server.controller.js', err);
    }else{
      console.info(result)
      res.json(result);
    }
  })
  //then connnect mongodb in server.js
};

exports.createAdminAccount = function(req, res) {
  console.log('new Admin data');
  console.log(req.body);
  var newUserAdmin = new Admin(req.body);
  newUserAdmin.save(function(err, result){
    if (err){
      console.log('save new user error at user_api.server.controller.js', err);
    }else{
      console.info(result)
      res.json(result);
    }
  })
  //then connnect mongodb in server.js
};

//username:req.params.username

exports.lists = function(req, res) {
  if (req.params.username){
    Cricketer.find({username:req.params.username},function(err, result){
      if (err){
        console.log('get new user error at user_api.server.controller.js', err);
      }else{
        console.info(result)
        res.json(result);
      }
    })
  }else{
    console.log("w/o username");
    Cricketer.find({},function(err, results){
      if (err){
        console.log('get new user error at user_api.server.controller.js', err);
      }else{
        console.info(results)
        res.json(results);
      }
    })
    // then connnect mongodb in server.js
  }
};


exports.allCricketers = function() {
    Cricketer.find({},function(err, result){
      if (err){
        console.log('get new user error at user_api.server.controller.js', err);
      }else{
        console.info(results)
        res.json(result);
      }
    })
};

exports.loginUser = function(req, res){
  // console.log(req.params.username, req.params.password);
  console.log(req.params.password);
  Admin.find({
    'username':req.params.username,
    'password':req.params.password
  },function(err, result){
    if (err){
      console.log('get new user error at user_api.server.controller.js', err);
    }else{
      console.log('server login user result',result);
      res.json(result);
    }
  })
};

exports.updateUser = function(req, res){
  var ObjectId = require('mongodb').ObjectID;

  console.log("params",new ObjectId(req.params.id));
  Cricketer.update(
    {'_id' : new ObjectId(req.params.id)},
    {$set: {

      'firstname' : req.body.firstname,
      'lastname' : req.body.lastname,
    'jersey_number' : req.body.jersey_number,
    'category' : req.body.category,
    'total_score' : req.body.total_score,
    'total_matches' : req.body.total_matches,
    'location' : req.body.location}},

      // 'username' : req.body.username,
      // 'password' : req.body.password,
      // 'firstname' : req.body.firstname,
      // 'lastname' : req.body.lastname,
      // 'email' : req.body.email,
      // 'phone' : req.body.phone,
      // 'location' : req.body.location}},
      function(err, result){
        console.log("editing upjdateing ", result);
        res.json(result);
      }
    )
}
