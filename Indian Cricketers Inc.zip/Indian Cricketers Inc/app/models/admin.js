var mongoose = require('mongoose');

module.exports = mongoose.model('Admin', {  //User
  username: String,
  password: String,
//   firstname: String,
//   lastname: String,
//   email: String,
//   phone: Number,
//   location: String
})