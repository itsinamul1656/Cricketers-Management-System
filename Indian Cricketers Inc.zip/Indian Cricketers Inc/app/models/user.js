var mongoose = require('mongoose');

module.exports = mongoose.model('Cricketer', {  //User
  firstname: String,
  lastname: String,
  jersey_number: String,
    category: String,
    total_score: String,
    total_matches: String,
    location: String,

  // username: String,
  // password: String,
  // firstname: String,
  // lastname: String,
  // email: String,
  // phone: Number,
  // location: String
})
