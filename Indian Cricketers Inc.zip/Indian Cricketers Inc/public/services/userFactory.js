angular.module('indianCricket')

.factory("userServices", function($resource, $state) {
    var factory = {};


    // resolve: {
    // get All users
    // Users:  function(userServices){
    //   return userServices.getUsers();
    // }
    factory.getUsers = function() {
        var Users = $resource('api/newUser/');
        return Users.query(function(results) {
            return results;
        })
    };
    factory.getAuser = function(name) {
        var User = $resource('api/newUser/:username');
        return User.get({ username: name }, function(result) {
            return result;
        });
    };

    factory.loginUser = function(name, pass) {  
        var User = $resource('api/newUser/:username/:password', {}, { get: { method: 'get', params: { username: name, password: pass }, isArray: true } });
        return User;
    };
    //
    factory.allCricketers = function() {
        var Users = $resource('api/newUser/');
        return Users.query(function(results) {
            return results;
        })
    };


    factory.checkForUserLogin = function(state, elState = "") {
        var user = JSON.parse(sessionStorage.getItem("currentUser"));
        if (user) {
            $state.go(state, {
                username: user.username
            });
        } else if (elState != "") {
            $state.go(elState);
        }
    };

    factory.saveUser_admin = function(userInfo) {
        var Admin = $resource('api/newUserAdmin/');
        var newUser = new Admin();
        newUser.username = userInfo.username;
        newUser.password = userInfo.password;
        // newUser.firstname = userInfo.firstname;
        // newUser.lastname = userInfo.lastname;
        // newUser.total_score = userInfo.total_score;
        // newUser.total_matches = userInfo.total_matches;
        // newUser.location = userInfo.location;
        
        newUser.$save(function(result) {    
            // console.info("========================");
            // console.info("newUser: ", newUser);
            // console.info("saving: ", result);
            // console.info("========================");
            sessionStorage.setItem('currentUser', JSON.stringify(result));
            $state.go("home", {
                username: result.username
            });
        });
    }

    factory.saveUser = function(userInfo) {
        var Cricketer = $resource('api/newUser/');
        var newUser = new Cricketer();
        newUser.jersey_number = userInfo.jersey_number;
        newUser.category = userInfo.category;
        newUser.firstname = userInfo.firstname;
        newUser.lastname = userInfo.lastname;
        newUser.total_score = userInfo.total_score;
        newUser.total_matches = userInfo.total_matches;
        newUser.location = userInfo.location;

        // // $scope.userInfo._id = currentUser._id;
        // // $scope.userInfo.firstname = currentUser.firstname;
        // // $scope.userInfo.lastname = currentUser.lastname;
        // // $scope.userInfo.jersey_number = currentUser.jersey_number;
        // // $scope.userInfo.name = currentUser.firstname + " " + currentUser.lastname;
        // // $scope.userInfo.category = currentUser.category;
        // // $scope.userInfo.total_score = currentUser.total_score;
        // // $scope.userInfo.total_matches = currentUser.total_matches;
        // // $scope.userInfo.location = currentUser.location
        
        newUser.$save(function(result) {
            // console.info("========================");
            // console.info("newUser: ", newUser);
            // console.info("saving: ", result);
            // console.info("========================");
            sessionStorage.setItem('currentUser', JSON.stringify(result));
            $state.go("home", {
                username: result.firstname + "_" + result.lastname
            });
        });
    }

    factory.saveEditUser = function(userInfo) {

        var User = $resource('api/updateUser/:id', { id: userInfo._id }, { 'update': { method: 'PUT' } });

        var newUser = new User(userInfo);
        return User.update(newUser).$promise.then(function(result) {
            if (result.nModified == 1) {
                sessionStorage.setItem("currentUser", JSON.stringify(userInfo));
                $state.go("home", {
                    username: userInfo.firstname + "_" + userInfo.lastname //userInfo.username
                });
            }
            return result;
        });
    }

    return factory;
})